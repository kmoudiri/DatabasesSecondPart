package myProjectVaseis;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DbApp {
	
	
	Connection conn;

	
	public DbApp() {
		try {
			Class.forName("org.postgresql.Driver");
			
			conn  = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/myDatabase", "postgres", "6971584647");
			conn.setAutoCommit(false);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	
	public void analutiki(String am){
		
		try {
			PreparedStatement pst=conn.prepareStatement("SELECT r.final_grade,r.course_code "+
														"FROM \"Register\" r "+
				" WHERE r.amka IN (SELECT s.amka FROM \"Student\" s WHERE s.am=? ) AND r.register_status='pass' ;");
			pst.setString(1, am);
			
			
			ResultSet rs = pst.executeQuery();
			
			while (rs.next()) {
			System.out.println("Grade of Student is: " + rs.getFloat(1)+ " - "+ rs.getString(2) + "");
			}
			rs.close();
			pst.close();
		} catch (Exception ex){          
			ex.printStackTrace();
		}

	}
	
	
	public void commit() {
		try {
			conn.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void abort() {
		try {
			conn.rollback();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void StudentGradeChange(String ccode,String am)
	{
		
		try {
			
			DbApp db = new DbApp();
			
			PreparedStatement pst=conn.prepareStatement("SELECT r.final_grade "+
					"FROM \"Register\" r "+
					" WHERE r.amka IN (SELECT s.amka FROM \"Student\" s WHERE s.am=? ) AND (r.course_code=?) AND serial_number = (		SELECT  serial_number" + 
					"		FROM (\r\n" + 
					"			(SELECT cr.course_code, MAX(cr.serial_number) AS serial_number" + 
					"			FROM \"CourseRun\" cr" + 
					"			WHERE cr.serial_number<=22 AND course_code= ? " + 
					"			GROUP BY course_code) q JOIN \"Register\" r USING  (serial_number, course_code))" + 
					"		WHERE amka= (SELECT s.amka FROM \"Student\" s WHERE am = ? ));");
			pst.setString(1, am);
			pst.setString(2, ccode);
			pst.setString(3, ccode);
			pst.setString(4, am);
			
			
			ResultSet res = pst.executeQuery();
			
			res.next();
			System.out.println(" The grade before change is: " + res.getFloat(1));
			
			int grade;
			do
			{
				Scanner keyboard = new Scanner(System.in);
				System.out.println("Enter the new grade");
				grade = keyboard.nextInt();
			}while(grade>10 || grade<0);
			
			pst=conn.prepareStatement("update \"Register\" set final_grade = ? "+
					"where amka = (SELECT amka FROM \"Student\" WHERE am = ?) "+
					" AND (course_code=?) AND (serial_number=(		SELECT  serial_number\r\n" + 
					"		FROM (\r\n" + 
					"			(SELECT cr.course_code, MAX(cr.serial_number) AS serial_number\r\n" + 
					"			FROM \"CourseRun\" cr\r\n" + 
					"			WHERE cr.serial_number<=22 AND course_code= ? \r\n" + 
					"			GROUP BY course_code) q JOIN \"Register\" r USING  (serial_number, course_code))\r\n" + 
					"		WHERE amka=  (SELECT s.amka FROM \"Student\" s WHERE am = ? )  ));");

			
			pst.setInt(1, grade);
			pst.setString(2, am);
			pst.setString(3, ccode);
			pst.setString(4, ccode);
			pst.setString(5, am);
			
					
			pst.executeUpdate();
				
			pst=conn.prepareStatement("SELECT r.final_grade "+
					"FROM \"Register\" r "+
					" WHERE r.amka IN (SELECT s.amka FROM \"Student\" s WHERE s.am=? ) AND (r.course_code=?)  AND serial_number=(		SELECT  serial_number\r\n" + 
					"		FROM (\r\n" + 
					"			(SELECT cr.course_code, MAX(cr.serial_number) AS serial_number\r\n" + 
					"			FROM \"CourseRun\" cr\r\n" + 
					"			WHERE cr.serial_number<=22 AND course_code= ? \r\n" + 
					"			GROUP BY course_code) q JOIN \"Register\" r USING  (serial_number, course_code))\r\n" + 
					"		WHERE amka= (SELECT s.amka FROM \"Student\" s WHERE am = ? ) );");
			pst.setString(1, am);
			pst.setString(2, ccode);
			pst.setString(3, ccode);
			pst.setString(4, am);

			res = pst.executeQuery();

			res.next();
			System.out.println("The new grade is: " + res.getFloat(1) );
			
			
			res.close();
			pst.close();
		} catch (Exception ex){          
			ex.printStackTrace();
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DbApp dbapp = new DbApp();
		
		
		Scanner keyboard = new Scanner(System.in);
		System.out.println("enter am for analutiki: ");
		String a = keyboard.nextLine();
		dbapp.analutiki(a);
		
/**************************************************************/		
		
		Scanner am = new Scanner(System.in);
		System.out.println("enter am for grade: ");
		String b = am.nextLine();
		
		Scanner cc = new Scanner(System.in);
		System.out.println("enter course code for grade: ");
		String c = cc.nextLine();
		
		
		//dbapp.StudentGradeChange("��� 402", "2015000008");
		dbapp.StudentGradeChange(c, b);
		

	}
	
	

}
